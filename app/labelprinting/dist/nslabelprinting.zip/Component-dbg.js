sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("ns.labelprinting.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);